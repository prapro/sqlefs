<?php
require 'sqlefs.class.php';
$efs = new efsclass();
# optionally you may add setup code here like...
# $efs->connect('mysql:mysql:host=localhost;dbname=myefsdb name pass');
# $efs->cd('admin!@c:\');
?>